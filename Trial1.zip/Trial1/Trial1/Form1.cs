﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trial1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblText.Text = "Hello World";
        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            lblText.Text = "Hello World Again and Again....";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            lblText.Text = "Text has been canceled";
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();//hide the page we are in

            LoginForm login = new LoginForm();
            login.Show();
        }
    }
}
